package com.qut.util;

import org.apache.log4j.Logger;

public class Log4jLogsDetial {

	private static Logger log = Logger.getLogger(Log4jLogsDetial.class);

	public static void main(String[] args) {
		log.info("信息日志开始:");

	}

}
